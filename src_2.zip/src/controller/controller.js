export class Controller {
    constructor() {}

    homePage(req, res) {
        res.render('index');
    }
}